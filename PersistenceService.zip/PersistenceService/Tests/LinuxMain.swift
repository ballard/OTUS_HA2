import XCTest

import PersistenceServiceTests

var tests = [XCTestCaseEntry]()
tests += PersistenceServiceTests.allTests()
XCTMain(tests)
